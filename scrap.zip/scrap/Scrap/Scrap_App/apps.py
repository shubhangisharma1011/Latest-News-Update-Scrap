from django.apps import AppConfig


class ScrapAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Scrap_App'
